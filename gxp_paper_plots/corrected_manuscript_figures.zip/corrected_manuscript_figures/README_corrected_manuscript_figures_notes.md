# Notes on the images uploaded for the GXP paper correction: 

Figure 1 f: Replaced the screenshot which was containing the mouse cursor with a new screenshot. The image is png format as its taken as a screenshot.

Figure 3 a: Replaced with sharper image. Rescaled the image to include the right part that was missing in the tree diagram. Both svg and png images are provided.

Figure 4 a, b, and c: Replaced the screenshots with new images where the text on colored stripes / scale and the strip  itself  does not overlap. Both png and svg images are provided but the svg images are directly exported from the Gene Expression Plotter. Therefore, the svg images do not contain the distribution table seen in the png images. This distribution table is described in the figure 4 legend. 

